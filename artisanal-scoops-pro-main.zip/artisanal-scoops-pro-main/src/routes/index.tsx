import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { assignRole, listUsersWithRoles, removeRole } from "@/lib/roles.functions";
import { Package, Phone, MapPin, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useServerFn } from "@tanstack/react-start";
import type { Session } from "@supabase/supabase-js";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MELTORA — Where Every Scoop Feels Special" },
      { name: "description", content: "Order premium handcrafted scoops, tubs, sundaes, sorbets and popsicles from MELTORA." },
      { property: "og:title", content: "MELTORA — Premium Ice Cream" },
      { property: "og:description", content: "Where Every Scoop Feels Special." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const CATEGORIES = ["Scoops", "Tubs", "Sundaes", "Sorbets", "Popsicles"] as const;
const BADGES = ["Eggless", "Organic", "Vegan", "Sugar-Free"] as const;
const FALLBACK_PHONE = "+91 9363180012";
type Role = "owner" | "manager" | "staff" | "customer";
type PartnerApp = { name: string; url: string };
type Settings = { phone: string; instagram: string; apps: PartnerApp[] };
const validAppUrl = (url: string) => { try { return ["https:", "http:"].includes(new URL(url).protocol); } catch { return false; } };
const readApps = (value: unknown): PartnerApp[] => Array.isArray(value) ? value.filter((app): app is PartnerApp => !!app && typeof app.name === "string" && typeof app.url === "string" && validAppUrl(app.url)) : [];
type Application = { id: number; full_name: string; phone: string; experience: string | null; why_join: string | null; available_shifts: string | null; prior_experience: string | null; status: string; applied_at: string };
type Item = {
  id: string; name: string; description: string; category: string; badges: string[];
  image: string; stock: number; single: number; double: number; tub: number;
};
type Size = "Single" | "Double" | "500ml Tub";
type Line = { key: string; itemId: string; name: string; size: Size; price: number; qty: number };

const inr = (n: number) => "₹" + n.toLocaleString("en-IN", { maximumFractionDigits: 2 });
const empty: Item = { id: "", name: "", description: "", category: "Scoops", badges: [], image: "", stock: 10, single: 0, double: 0, tub: 0 };

function useStored<T>(key: string, init: T) {
  const [v, setV] = useState<T>(init);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    try { const s = localStorage.getItem(key); if (s) setV(JSON.parse(s)); } catch {}
    setReady(true);
  }, [key]);
  useEffect(() => { if (ready) localStorage.setItem(key, JSON.stringify(v)); }, [key, v, ready]);
  return [v, setV] as const;
}

function Index() {
  const [roles, setRoles] = useState<Role[]>([]);
  const [settings, setSettings] = useState<Settings>({ phone: FALLBACK_PHONE, instagram: "Coming Soon", apps: [] });
  const [items, setItems] = useState<Item[]>([]);
  const [session, setSession] = useState<Session | null>(null);
  const [error, setError] = useState("");
  const load = async () => {
    const { data } = await supabase.from("flavours").select("*").order("created_at");
    setItems((data ?? []).map((r) => ({
      id: r.id, name: r.name, description: r.description ?? "", category: r.category ?? "Scoops",
      badges: r.badges ?? [], image: r.image_url ?? "", stock: r.stock_count ?? 0,
      single: Number(r.price_single), double: Number(r.price_double), tub: Number(r.price_tub),
    })));
  };
  const loadSettings = async () => {
    const { data } = await supabase.from("website_settings").select("*").eq("id", 1).maybeSingle();
    if (data) setSettings({ phone: data.phone_number ?? FALLBACK_PHONE, instagram: data.instagram_id ?? "Coming Soon", apps: readApps(data.apps) });
  };
  const loadRoles = async (s: Session | null) => {
    if (!s) { setRoles([]); return; }
    const { data } = await supabase.from("user_roles").select("role").eq("user_id", s.user.id);
    setRoles(((data ?? []).map((r) => r.role) as Role[]));
  };
  useEffect(() => {
    load();
    loadSettings();
    supabase.auth.getSession().then(({ data }) => { setSession(data.session); loadRoles(data.session); });
    const { data: sub } = supabase.auth.onAuthStateChange((_e, s) => { setSession(s); loadRoles(s); });
    return () => sub.subscription.unsubscribe();
  }, []);
  const [cart, setCart] = useStored<Line[]>("meltora-cart", []);
  const [filter, setFilter] = useState("All");
  const [editing, setEditing] = useState<Item | null>(null);
  const [cartOpen, setCartOpen] = useState(false);
  const [checkout, setCheckout] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const isOwner = roles.includes("owner");
  const isManager = roles.includes("manager");
  const [section, setSection] = useState("Customer");
  const staff = !!session && (isOwner || isManager || roles.includes("staff"));

  const sections = [...(isOwner || roles.includes("staff") ? ["Owner"] : []), ...(staff ? ["Manager", "Orders"] : []), "Customer", ...(isOwner || isManager ? ["Applications", "Role Management"] : [])];
  const activeSection = sections.includes(section) ? section : "Customer";

  const shown = filter === "All" ? items : items.filter((i) => i.category === filter);
  const subtotal = cart.reduce((s, l) => s + l.price * l.qty, 0);
  const gst = subtotal * 0.05;
  const count = cart.reduce((s, l) => s + l.qty, 0);

  const add = (it: Item, size: Size, price: number) =>
    setCart((c) => {
      const key = it.id + size;
      const ex = c.find((l) => l.key === key);
      return ex ? c.map((l) => (l.key === key ? { ...l, qty: l.qty + 1 } : l))
        : [...c, { key, itemId: it.id, name: it.name, size, price, qty: 1 }];
    });
  const setQty = (key: string, d: number) =>
    setCart((c) => c.map((l) => (l.key === key ? { ...l, qty: l.qty + d } : l)).filter((l) => l.qty > 0));

  const save = async (it: Item) => {
    try {
      const { data: auth, error: authError } = await supabase.auth.getUser();
      if (authError || !auth.user) throw new Error("Please sign in again to save flavors.");
      const row = { name: it.name.trim(), description: it.description, category: it.category, badges: it.badges,
        image_url: it.image, stock_count: it.stock, price_single: it.single, price_double: it.double, price_tub: it.tub };
      const result = it.id ? await supabase.from("flavours").update(row).eq("id", it.id).select("id").single()
        : await supabase.from("flavours").insert(row).select("id").single();
      if (result.error) throw result.error;
      setError(""); await load(); setEditing(null);
      toast.success(it.id ? `"${it.name}" updated successfully!` : `"${it.name}" added to the menu!`);
    } catch (err) {
      const message = err instanceof Error ? err.message : "Unable to save flavor";
      setError(message); toast.error("Failed to save flavor: " + message);
    }
  };

  return (
    <div className="min-h-screen pb-28">
      {/* Account bar */}
      <div className="bg-primary text-primary-foreground text-xs">
        <div className="mx-auto flex max-w-6xl items-center justify-between gap-2 px-4 py-2">
          <span className="opacity-70">{session ? `Signed in · ${roles.length ? roles.join(", ") : "customer"}` : "Browsing as guest"}</span>
          {session && (
            <button onClick={() => supabase.auth.signOut()} className="rounded-full bg-primary-foreground/10 px-3 py-1 font-medium hover:bg-primary-foreground/20">
              Sign out
            </button>
          )}
        </div>
      </div>

      <header className="sticky top-0 z-30 border-b bg-background/90 backdrop-blur">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-4 py-3">
          <div>
            <h1 className="text-2xl font-extrabold tracking-[0.2em]">MELTORA</h1>
            <p className="text-[10px] uppercase tracking-widest text-gold">Premium Ice Cream</p>
          </div>
          <button onClick={() => setCartOpen(true)} className="relative rounded-full border bg-card px-4 py-2 text-sm font-medium">
            Cart
            {count > 0 && <span className="absolute -right-1 -top-1 grid h-5 w-5 place-items-center rounded-full bg-accent text-[10px] font-bold">{count}</span>}
          </button>
        </div>
      </header>

      <section className="bg-hero">
        <div className="mx-auto max-w-6xl px-4 py-14 text-center">
          <p className="text-xs uppercase tracking-[0.3em] text-gold">Handcrafted daily</p>
          <h2 className="mt-3 text-4xl font-bold leading-tight md:text-6xl">Where Every Scoop<br /><em className="font-medium">Feels Special.</em></h2>
          <p className="mx-auto mt-4 max-w-md text-muted-foreground">Small-batch flavours, churned slow and served with love.</p>
          {staff && (
            <button onClick={() => setEditing({ ...empty })} className="mt-6 rounded-full bg-primary px-6 py-3 text-sm font-medium text-primary-foreground shadow-soft">
              + Add New Flavor
            </button>
          )}
        </div>
      </section>

      <main className="mx-auto max-w-6xl px-4 py-8">
        {!session && <StaffSignIn />}
        <nav aria-label="Shop sections" className="mb-6 flex flex-wrap gap-2 border-b pb-4">
          {sections.map((name) => <Button key={name} variant={activeSection === name ? "default" : "outline"} onClick={() => setSection(name)}>{name}</Button>)}
        </nav>
        <h2 className="mb-5 text-2xl font-bold">{activeSection} Section</h2>
        {activeSection === "Customer" && session && !staff && <StaffApplication session={session} />}
        {activeSection === "Owner" && (isOwner || roles.includes("staff")) && <section className="mb-8 flex flex-wrap gap-3 border-b pb-6">
          <Button onClick={() => setEditing({ ...empty })}>Add New Flavor</Button>
          {isOwner && <Button variant="outline" onClick={() => setSettingsOpen(true)}>Edit Footer Settings</Button>}
        </section>}
        {activeSection === "Manager" && staff && <section className="mb-8 border-b pb-6"><Button onClick={() => setEditing({ ...empty })}>Add New Flavor</Button></section>}
        {activeSection === "Orders" && staff && <OrdersPanel />}
        {activeSection === "Applications" && (isOwner || isManager) && <ApplicationsPanel />}
        {activeSection === "Role Management" && (isOwner || isManager) && <RoleManager isOwner={isOwner} />}
        {error && <p className="mb-4 rounded-xl bg-destructive/10 px-4 py-2 text-sm text-destructive">{error}</p>}
        <div className="-mx-4 mb-6 flex gap-2 overflow-x-auto px-4">
          {["All", ...CATEGORIES].map((c) => (
            <button key={c} onClick={() => setFilter(c)}
              className={`shrink-0 rounded-full border px-4 py-1.5 text-sm ${filter === c ? "border-primary bg-primary text-primary-foreground" : "bg-card"}`}>{c}</button>
          ))}
        </div>

        {shown.length === 0 ? (
          <div className="rounded-3xl border border-dashed bg-card p-12 text-center">
            <h3 className="text-2xl font-bold">The menu is being churned</h3>
            <p className="mt-2 text-sm text-muted-foreground">
              {staff ? "Add your first flavour to get started." : "Fresh flavours are coming soon. Check back shortly!"}
            </p>
            {staff && <button onClick={() => setEditing({ ...empty })} className="mt-5 rounded-full bg-primary px-5 py-2.5 text-sm text-primary-foreground">+ Add New Flavor</button>}
          </div>
        ) : (
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
            {shown.map((it) => (
              <article key={it.id} className="overflow-hidden rounded-3xl border bg-card shadow-soft">
                <div className="relative aspect-[4/3] bg-accent/40">
                  {it.image ? <img src={it.image} alt={it.name} className="h-full w-full object-cover" />
                    : <div className="grid h-full place-items-center font-serif text-5xl text-primary/30">M</div>}
                  <div className="absolute left-3 top-3 flex flex-wrap gap-1">
                    {it.badges.map((b) => <span key={b} className="rounded-full bg-background/90 px-2.5 py-0.5 text-[11px] font-medium">{b}</span>)}
                  </div>
                  <span className={`absolute bottom-3 right-3 rounded-full px-2.5 py-0.5 text-[11px] font-bold ${it.stock > 0 ? "bg-gold text-gold-foreground" : "bg-destructive text-destructive-foreground"}`}>
                    {it.stock > 0 ? `${it.stock} left` : "Sold out"}
                  </span>
                </div>
                <div className="p-5">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-xl font-bold">{it.name}</h3>
                    <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{it.category}</span>
                  </div>
                  <p className="mt-1 text-sm text-muted-foreground">{it.description}</p>
                  <div className="mt-4 grid grid-cols-2 gap-2">
                    {([["Single", it.single], ["Double", it.double]] as const).map(([s, p]) => (
                      <button key={s} disabled={it.stock <= 0} onClick={() => add(it, s, p)}
                        className="rounded-xl border bg-background px-3 py-2 text-left text-sm transition hover:border-primary disabled:opacity-40">
                        <span className="block text-xs text-muted-foreground">{s}</span>
                        <span className="font-bold">{inr(p)}</span>
                      </button>
                    ))}
                  </div>
                  <button disabled={it.stock <= 0} onClick={() => add(it, "500ml Tub", it.tub)}
                    className="mt-2 w-full rounded-xl bg-accent px-3 py-2.5 text-sm font-medium disabled:opacity-40">
                    + Add 500ml Tub ({inr(it.tub)})
                  </button>
                  {staff && (
                    <div className="mt-3 flex gap-2 border-t pt-3">
                      <button onClick={() => setEditing(it)} className="flex-1 rounded-lg border px-3 py-1.5 text-sm">Edit</button>
                      <button onClick={() => { if (confirm(`Delete ${it.name}?`)) supabase.from("flavours").delete().eq("id", it.id).then(({ error }) => {
                        if (error) { toast.error("Failed to delete: " + error.message); return; }
                        toast.success(`"${it.name}" removed from the menu.`);
                        load();
                      }); }}
                        className="flex-1 rounded-lg border border-destructive/40 px-3 py-1.5 text-sm text-destructive">Delete</button>
                    </div>
                  )}
                </div>
              </article>
            ))}
          </div>
        )}
      </main>

      <footer className="border-t bg-card">
        <div className="mx-auto grid max-w-6xl gap-4 px-4 py-10 text-sm sm:grid-cols-3">
          <div><p className="font-serif text-xl font-bold tracking-[0.2em]">MELTORA</p><p className="text-muted-foreground">Where Every Scoop Feels Special.</p></div>
          <div><p className="font-medium">Call us</p><a href={`tel:${settings.phone.replace(/\s/g, "")}`} className="text-muted-foreground">{settings.phone}</a></div>
          <div>
            <p className="font-medium">Instagram</p>
            <p className="text-muted-foreground">{settings.instagram}</p>
            {isOwner && <button onClick={() => setSettingsOpen(true)} className="mt-1 text-xs text-gold underline">Edit footer settings</button>}
          </div>
        </div>
        {settings.apps.length > 0 && <div className="mx-auto flex max-w-6xl flex-wrap gap-4 px-4 pb-10" aria-label="Partner and delivery apps">
          {settings.apps.map((app, index) => <a key={`${app.url}-${index}`} href={app.url} target="_blank" rel="noopener noreferrer" className="text-sm text-primary underline">{app.name} ↗</a>)}
        </div>}
      </footer>

      {settingsOpen && isOwner && (
        <SettingsEditor
          initial={settings}
          onClose={() => setSettingsOpen(false)}
          onSave={async (s) => {
            const { error } = await supabase.from("website_settings").update({ phone_number: s.phone, instagram_id: s.instagram, apps: s.apps, updated_at: new Date().toISOString() }).eq("id", 1).select("id").single();
            if (error) { toast.error("Failed to save settings: " + error.message); return; }
            setSettings(s); setSettingsOpen(false); toast.success("Footer settings saved.");
          }}
        />
      )}

      {count > 0 && !cartOpen && (
        <div className="fixed inset-x-0 bottom-0 z-30 p-3">
          <button onClick={() => setCartOpen(true)} className="mx-auto flex w-full max-w-xl items-center justify-between rounded-2xl bg-primary px-5 py-4 text-primary-foreground shadow-soft">
            <span className="text-sm">{count} item{count > 1 ? "s" : ""} · {inr(subtotal + gst)}</span>
            <span className="font-medium text-gold">View Cart →</span>
          </button>
        </div>
      )}

      {cartOpen && (
        <Overlay onClose={() => setCartOpen(false)} side>
          <h3 className="text-2xl font-bold">Your Cart</h3>
          {cart.length === 0 ? <p className="mt-6 text-sm text-muted-foreground">Your cart is empty.</p> : (
            <>
              <ul className="mt-4 flex-1 space-y-3 overflow-y-auto">
                {cart.map((l) => (
                  <li key={l.key} className="flex items-center justify-between rounded-xl border bg-card p-3">
                    <div><p className="font-medium">{l.name}</p><p className="text-xs text-muted-foreground">{l.size} · {inr(l.price)}</p></div>
                    <div className="flex items-center gap-2">
                      <button onClick={() => setQty(l.key, -1)} className="h-7 w-7 rounded-full border">−</button>
                      <span className="w-4 text-center text-sm">{l.qty}</span>
                      <button onClick={() => setQty(l.key, 1)} className="h-7 w-7 rounded-full border">+</button>
                    </div>
                  </li>
                ))}
              </ul>
              <Totals subtotal={subtotal} gst={gst} />
              <button onClick={() => { setCartOpen(false); setCheckout(true); }} className="mt-4 w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground">Checkout</button>
            </>
          )}
        </Overlay>
      )}

      {checkout && <Checkout cart={cart} subtotal={subtotal} gst={gst} phone={settings.phone} onClose={() => setCheckout(false)}
        onDone={() => {
          setCart([]);
        }} />}

      {editing && <Editor initial={editing} onClose={() => setEditing(null)} onSave={save} />}
    </div>
  );
}

function Overlay({ children, onClose, side }: { children: React.ReactNode; onClose: () => void; side?: boolean }) {
  return (
    <div role="dialog" aria-modal="true" className="fixed inset-x-0 top-0 bottom-16 z-50 flex bg-primary/40 backdrop-blur-sm" onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()}
        className={side ? "ml-auto flex h-full w-full max-w-md flex-col bg-background p-6 animate-in slide-in-from-right"
          : "m-auto flex max-h-[calc(100dvh-6rem)] w-[calc(100%-1.5rem)] max-w-lg flex-col overflow-y-auto rounded-3xl bg-background p-6 animate-in zoom-in-95"}>
        <button onClick={onClose} className="self-end text-sm text-muted-foreground">Close ✕</button>
        {children}
      </div>
    </div>
  );
}

function Totals({ subtotal, gst }: { subtotal: number; gst: number }) {
  return (
    <div className="mt-4 space-y-1 border-t pt-4 text-sm">
      <div className="flex justify-between"><span className="text-muted-foreground">Subtotal</span><span>{inr(subtotal)}</span></div>
      <div className="flex justify-between"><span className="text-muted-foreground">GST (5%)</span><span>{inr(gst)}</span></div>
      <div className="flex justify-between pt-1 text-lg font-bold"><span>Total</span><span>{inr(subtotal + gst)}</span></div>
    </div>
  );
}

function Checkout({ cart, subtotal, gst, phone: shopPhone, onClose, onDone }: { cart: Line[]; subtotal: number; gst: number; phone: string; onClose: () => void; onDone: () => void }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [placed, setPlaced] = useState(false);
  const [saving, setSaving] = useState(false);
  const valid = name.trim().length > 1 && /^[6-9]\d{9}$/.test(phone);
  const placeOrder = async () => {
    if (!valid || saving || cart.length === 0) return;
    setSaving(true);
    const { error } = await supabase.from("orders").insert({
      customer_name: name.trim(),
      customer_phone: `+91${phone}`,
      customer_address: address.trim() || null,
      items: cart.map((l) => ({ name: l.name, size: l.size, price: l.price, qty: l.qty })),
      subtotal,
      gst,
      total: subtotal + gst,
    });
    setSaving(false);
    if (error) { toast.error("Could not place order: " + error.message); return; }
    toast.success("Order placed! We'll call you to confirm.");
    onDone();
    setPlaced(true);
  };
  if (placed) return (
    <Overlay onClose={onClose}>
      <div className="py-6 text-center">
        <h3 className="text-3xl font-bold">Order placed!</h3>
        <p className="mt-2 text-sm text-muted-foreground">We'll call you on +91 {phone} to confirm. Questions? Call {shopPhone}.</p>
        <button onClick={onClose} className="mt-6 rounded-full bg-primary px-6 py-2.5 text-primary-foreground">Done</button>
      </div>
    </Overlay>
  );
  return (
    <Overlay onClose={onClose}>
      <h3 className="text-2xl font-bold">Order Summary</h3>
      <ul className="mt-4 space-y-2 text-sm">
        {cart.map((l) => <li key={l.key} className="flex justify-between"><span>{l.qty} × {l.name} <span className="text-muted-foreground">({l.size})</span></span><span>{inr(l.price * l.qty)}</span></li>)}
      </ul>
      <Totals subtotal={subtotal} gst={gst} />
      <label className="mt-5 block text-sm font-medium">Your name</label>
      <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Full name"
        className="mt-1 w-full rounded-xl border bg-card px-3 py-2.5 text-sm outline-none focus:border-gold" />
      <label className="mt-4 block text-sm font-medium">Phone number</label>
      <div className="mt-1 flex overflow-hidden rounded-xl border bg-card">
        <span className="border-r px-3 py-2.5 text-sm text-muted-foreground">+91</span>
        <input inputMode="numeric" maxLength={10} value={phone} onChange={(e) => setPhone(e.target.value.replace(/\D/g, ""))}
          placeholder="10-digit mobile" className="flex-1 bg-transparent px-3 outline-none" />
      </div>
      <label className="mt-4 block text-sm font-medium">Delivery address <span className="text-muted-foreground">(optional)</span></label>
      <textarea rows={2} value={address} onChange={(e) => setAddress(e.target.value)} placeholder="House, street, area"
        className="mt-1 w-full rounded-xl border bg-card px-3 py-2.5 text-sm outline-none focus:border-gold" />
      <button disabled={!valid || cart.length === 0 || saving} onClick={placeOrder}
        className="mt-5 w-full rounded-xl bg-primary py-3 font-medium text-primary-foreground disabled:opacity-40">
        {saving ? "Placing…" : `Place Order · ${inr(subtotal + gst)}`}
      </button>
    </Overlay>
  );
}

function Editor({ initial, onClose, onSave }: { initial: Item; onClose: () => void; onSave: (i: Item) => Promise<void> }) {
  const [f, setF] = useState<Item>(initial);
  const set = <K extends keyof Item>(k: K, v: Item[K]) => setF((p) => ({ ...p, [k]: v }));
  const field = "mt-1 w-full rounded-xl border bg-card px-3 py-2 text-sm outline-none focus:border-gold";
  const [saving, setSaving] = useState(false);
  const ok = useMemo(() => !!f.name.trim() && Number.isInteger(f.stock) && f.stock >= 0 && [f.single, f.double, f.tub].every((n) => Number.isFinite(n) && n >= 0), [f]);
  const upload = (file?: File) => {
    if (!file) return;
    const r = new FileReader();
    r.onload = () => set("image", r.result as string);
    r.readAsDataURL(file);
  };
  return (
    <Overlay onClose={onClose}>
      <h3 className="text-2xl font-bold">{initial.id ? "Edit Flavor" : "Add New Flavor"}</h3>
      <form className="mt-4 space-y-3 text-sm" onSubmit={async (e) => { e.preventDefault(); if (!ok || saving) return; setSaving(true); try { await onSave(f); } finally { setSaving(false); } }}>
        <label className="block">Flavor / Product Name<input required className={field} value={f.name} onChange={(e) => set("name", e.target.value)} /></label>
        <label className="block">Short Description<textarea rows={2} className={field} value={f.description} onChange={(e) => set("description", e.target.value)} /></label>
        <label className="block">Category
          <select className={field} value={f.category} onChange={(e) => set("category", e.target.value)}>
            {CATEGORIES.map((c) => <option key={c}>{c}</option>)}
          </select>
        </label>
        <div>Dietary Badges
          <div className="mt-1 flex flex-wrap gap-2">
            {BADGES.map((b) => {
              const on = f.badges.includes(b);
              return <button type="button" key={b} onClick={() => set("badges", on ? f.badges.filter((x) => x !== b) : [...f.badges, b])}
                className={`rounded-full border px-3 py-1 ${on ? "border-primary bg-primary text-primary-foreground" : "bg-card"}`}>{b}</button>;
            })}
          </div>
        </div>
        <label className="block">Image URL<input className={field} placeholder="https://…" value={f.image.startsWith("data:") ? "" : f.image} onChange={(e) => set("image", e.target.value)} /></label>
        <label className="block">…or upload image<input type="file" accept="image/*" className={field} onChange={(e) => upload(e.target.files?.[0])} /></label>
        {f.image && <img src={f.image} alt="" className="h-24 w-24 rounded-xl object-cover" />}
        <div className="grid grid-cols-2 gap-3">
          <label>Stock quantity<input type="number" min={0} className={field} value={f.stock} onChange={(e) => set("stock", +e.target.value)} /></label>
          <label>Single Price (₹)<input type="number" min={0} step="0.01" required className={field} value={f.single} onChange={(e) => set("single", +e.target.value)} /></label>
          <label>Double Price (₹)<input type="number" min={0} step="0.01" required className={field} value={f.double} onChange={(e) => set("double", +e.target.value)} /></label>
          <label>500ml Tub Price (₹)<input type="number" min={0} step="0.01" required className={field} value={f.tub} onChange={(e) => set("tub", +e.target.value)} /></label>
        </div>
        <Button type="submit" disabled={!ok || saving} className="sticky bottom-0 w-full">
          {saving ? "Saving…" : initial.id ? "Save Changes" : "Add Flavor"}
        </Button>
      </form>
    </Overlay>
  );
}

function StaffSignIn() {
  const [mode, setMode] = useState<"in" | "up">("in");
  const [email, setEmail] = useState("");
  const [pw, setPw] = useState("");
  const [msg, setMsg] = useState("");
  const submit = async (e: React.FormEvent) => {
    e.preventDefault(); setMsg("");
    if (mode === "in") {
      const { error } = await supabase.auth.signInWithPassword({ email, password: pw });
      if (error) setMsg(error.message);
    } else {
      const { error } = await supabase.auth.signUp({ email, password: pw, options: { emailRedirectTo: window.location.origin } });
      setMsg(error ? error.message : "Check your inbox to confirm your account, then sign in.");
    }
  };
  const field = "w-full rounded-xl border bg-background px-3 py-2 text-sm outline-none focus:border-gold";
  return (
    <form onSubmit={submit} className="mx-auto mb-8 max-w-sm space-y-3 rounded-3xl border bg-card p-6 shadow-soft">
      <h3 className="text-xl font-bold">Staff {mode === "in" ? "Sign In" : "Sign Up"}</h3>
      <p className="text-xs text-muted-foreground">Sign in to add, edit or delete flavours.</p>
      <input type="email" required placeholder="Email" className={field} value={email} onChange={(e) => setEmail(e.target.value)} />
      <input type="password" required minLength={6} placeholder="Password" className={field} value={pw} onChange={(e) => setPw(e.target.value)} />
      {msg && <p className="text-xs text-muted-foreground">{msg}</p>}
      <button className="w-full rounded-xl bg-primary py-2.5 text-sm font-medium text-primary-foreground">{mode === "in" ? "Sign In" : "Create Account"}</button>
      <button type="button" onClick={() => setMode(mode === "in" ? "up" : "in")} className="w-full text-xs text-muted-foreground underline">
        {mode === "in" ? "New staff? Create an account" : "Have an account? Sign in"}
      </button>
    </form>
  );
}

function SettingsEditor({ initial, onClose, onSave }: { initial: Settings; onClose: () => void; onSave: (s: Settings) => Promise<void> }) {
  const [f, setF] = useState<Settings>(initial);
  const [saving, setSaving] = useState(false);
  const field = "mt-1 w-full rounded-xl border bg-card px-3 py-2 text-sm outline-none focus:border-gold";
  return (
    <Overlay onClose={onClose}>
      <h3 className="text-2xl font-bold">Footer Settings</h3>
      <form className="mt-4 space-y-4 text-sm" onSubmit={async (e) => {
        e.preventDefault();
        if (saving) return;
        if (f.apps.some((app) => !app.name.trim() || !validAppUrl(app.url))) { toast.error("Each app needs a name and an HTTP or HTTPS URL."); return; }
        setSaving(true);
        try { await onSave({ ...f, apps: f.apps.map((app) => ({ name: app.name.trim(), url: app.url.trim() })) }); }
        catch { toast.error("Unable to save footer settings."); }
        finally { setSaving(false); }
      }}>
        <label className="block">Phone number<input required className={field} value={f.phone} onChange={(e) => setF({ ...f, phone: e.target.value })} /></label>
        <label className="block">Instagram<input required className={field} value={f.instagram} onChange={(e) => setF({ ...f, instagram: e.target.value })} /></label>
        <h4 className="text-lg font-bold">Partner & Delivery Apps</h4>
        {f.apps.map((app, index) => <fieldset key={index} className="space-y-2 border-b pb-4">
          <label className="block">App Name<input required maxLength={100} className={field} value={app.name} onChange={(e) => setF({ ...f, apps: f.apps.map((a, i) => i === index ? { ...a, name: e.target.value } : a) })} /></label>
          <label className="block">App URL<input type="url" required className={field} placeholder="https://…" value={app.url} onChange={(e) => setF({ ...f, apps: f.apps.map((a, i) => i === index ? { ...a, url: e.target.value } : a) })} /></label>
          <Button type="button" variant="outline" aria-label={`Delete app ${app.name || index + 1}`} onClick={() => setF({ ...f, apps: f.apps.filter((_, i) => i !== index) })}>Delete App</Button>
        </fieldset>)}
        <Button type="button" variant="outline" onClick={() => setF({ ...f, apps: [...f.apps, { name: "", url: "" }] })}>Add App</Button>
        <Button type="submit" disabled={saving} className="w-full">{saving ? "Saving…" : "Save Settings"}</Button>
      </form>
    </Overlay>
  );
}

function StaffApplication({ session }: { session: Session }) {
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [exp, setExp] = useState("");
  const [why, setWhy] = useState("");
  const [shifts, setShifts] = useState("");
  const [prior, setPrior] = useState("");
  const [msg, setMsg] = useState("");
  const [existing, setExisting] = useState<Application | null>(null);
  useEffect(() => {
    supabase.from("staff_applications").select("*").eq("customer_id", session.user.id).order("applied_at", { ascending: false }).limit(1)
      .then(({ data }) => setExisting((data?.[0] as Application) ?? null));
  }, [session.user.id]);
  const field = "w-full rounded-xl border bg-background px-3 py-2 text-sm outline-none focus:border-gold";
  if (existing) return (
    <div className="mx-auto mb-8 max-w-sm rounded-3xl border bg-card p-6 text-center text-sm shadow-soft">
      <h3 className="text-xl font-bold">Staff Application</h3>
      <p className="mt-2 text-muted-foreground">Your application is <span className="font-medium text-foreground">{existing.status}</span>. We'll be in touch soon.</p>
    </div>
  );
  return (
    <form onSubmit={async (e) => {
      e.preventDefault(); setMsg("");
      const { data: auth } = await supabase.auth.getUser();
      if (!auth.user) { setMsg("Please sign in again."); return; }
      if ([name, phone, exp, why, shifts, prior].some((value) => !value.trim())) { setMsg("All application fields are required."); return; }
      const row = { customer_id: auth.user.id, full_name: name.trim(), phone: phone.trim(), experience: exp.trim(), why_join: why.trim(), available_shifts: shifts.trim(), prior_experience: prior.trim() };
      const { error } = await supabase.from("staff_applications").insert(row);
      if (error) { setMsg(error.message); return; }
      setExisting({ id: 0, ...row, status: "pending", applied_at: "" });
    }} className="mx-auto mb-8 max-w-sm space-y-3 rounded-3xl border bg-card p-6 shadow-soft">
      <h3 className="text-xl font-bold">Apply to Join Our Team</h3>
      <p className="text-xs text-muted-foreground">Want to work at MELTORA? Send us your details.</p>
      <input required placeholder="Full name" className={field} value={name} onChange={(e) => setName(e.target.value)} />
      <input required type="tel" placeholder="Phone" className={field} value={phone} onChange={(e) => setPhone(e.target.value)} />
      <textarea required rows={3} placeholder="Experience" className={field} value={exp} onChange={(e) => setExp(e.target.value)} />
      <textarea required rows={2} placeholder="Why do you want to join our staff team?" className={field} value={why} onChange={(e) => setWhy(e.target.value)} />
      <input required placeholder="What hours/shifts are you available?" className={field} value={shifts} onChange={(e) => setShifts(e.target.value)} />
      <textarea required rows={2} placeholder="Do you have prior experience in a similar role?" className={field} value={prior} onChange={(e) => setPrior(e.target.value)} />
      {msg && <p className="text-xs text-destructive">{msg}</p>}
      <button className="w-full rounded-xl bg-primary py-2.5 text-sm font-medium text-primary-foreground">Submit Application</button>
    </form>
  );
}

function RoleManager({ isOwner }: { isOwner: boolean }) {
  const [users, setUsers] = useState<{ id: string; email: string; roles: string[] }[]>([]);
  const [email, setEmail] = useState("");
  const [role, setRole] = useState<Role>("staff");
  const [msg, setMsg] = useState("");
  const list = useServerFn(listUsersWithRoles);
  const assign = useServerFn(assignRole);
  const remove = useServerFn(removeRole);
  const load = () => list().then(setUsers).catch(() => setMsg("Unable to load team roles."));
  useEffect(() => { load(); }, []);
  const field = "w-full rounded-xl border bg-background px-3 py-2 text-sm outline-none focus:border-gold";
  return (
    <div className="mb-8 rounded-3xl border bg-card p-6 shadow-soft">
      <h3 className="text-xl font-bold">Team Roles</h3>
      <ul className="mt-4 space-y-2">
        {users.map((u) => (
          <li key={u.id} className="flex flex-wrap items-center justify-between gap-2 rounded-xl border bg-background p-3 text-sm">
            <span className="font-medium">{u.email}</span>
            <span className="flex flex-wrap gap-1.5">
              {u.roles.length === 0 && <span className="text-xs text-muted-foreground">customer</span>}
              {u.roles.map((r) => (
                <span key={r} className="flex items-center gap-1 rounded-full bg-accent px-2.5 py-0.5 text-[11px] font-medium">
                  {r}
                  {isOwner && (
                    <button aria-label={`Remove ${r}`} onClick={async () => { try { await remove({ data: { userId: u.id, role: r } }); load(); toast.success("Role removed."); } catch { toast.error("Unable to remove role."); } }}
                      className="text-destructive">×</button>
                  )}
                </span>
              ))}
            </span>
          </li>
        ))}
      </ul>
      {isOwner && (
        <form onSubmit={async (e) => {
          e.preventDefault(); setMsg("");
          try { await assign({ data: { email, role } }); setEmail(""); load(); }
          catch (err: any) { setMsg(err.message ?? "Failed to assign role"); }
        }} className="mt-4 flex flex-col gap-2 sm:flex-row">
          <input required type="email" placeholder="Account email" className={field} value={email} onChange={(e) => setEmail(e.target.value)} />
          <select className={field} value={role} onChange={(e) => setRole(e.target.value as Role)}>
            {(["owner", "manager", "staff", "customer"] as const).map((r) => <option key={r} value={r}>{r}</option>)}
          </select>
          <button className="rounded-xl bg-primary px-4 py-2 text-sm font-medium text-primary-foreground">Assign</button>
        </form>
      )}
      {msg && <p className="mt-2 text-xs text-destructive">{msg}</p>}
    </div>
  );
}

type Order = {
  id: string;
  customer_name: string;
  customer_phone: string;
  customer_address: string | null;
  items: { name: string; size: string; price: number; qty: number }[] | null;
  total: number;
  status: string | null;
  created_at: string;
};

const ORDER_STATUSES = ["pending", "confirmed", "completed", "cancelled"] as const;

function OrdersPanel() {
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchOrders = async () => {
    const { data } = await supabase.from("orders").select("*").order("created_at", { ascending: false });
    if (data) setOrders(data as unknown as Order[]);
    setLoading(false);
  };

  useEffect(() => {
    fetchOrders();
    const channel = supabase
      .channel("orders-live")
      .on("postgres_changes", { event: "*", schema: "public", table: "orders" }, (payload) => {
        if (payload.eventType === "INSERT") setOrders((prev) => [payload.new as Order, ...prev]);
        else if (payload.eventType === "UPDATE") setOrders((prev) => prev.map((o) => (o.id === (payload.new as Order).id ? (payload.new as Order) : o)));
        else if (payload.eventType === "DELETE") setOrders((prev) => prev.filter((o) => o.id !== (payload.old as Order).id));
      })
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, []);

  const setStatus = async (id: string, status: string) => {
    const { error } = await supabase.from("orders").update({ status }).eq("id", id);
    if (error) toast.error("Could not update order: " + error.message);
    else toast.success(`Order marked ${status}.`);
  };

  const statusStyle = (s: string) =>
    s === "pending" ? "bg-accent text-primary" : s === "confirmed" ? "bg-gold/20 text-primary" : s === "completed" ? "bg-primary/10 text-primary" : "bg-destructive/10 text-destructive";

  if (loading) return <p className="text-sm text-muted-foreground">Loading orders…</p>;
  if (orders.length === 0) return (
    <div className="rounded-3xl border border-dashed bg-card p-12 text-center">
      <h3 className="text-2xl font-bold">No orders yet</h3>
      <p className="mt-2 text-sm text-muted-foreground">New customer orders will appear here live.</p>
    </div>
  );
  return (
    <div className="grid gap-4 md:grid-cols-2">
      {orders.map((order) => (
        <div key={order.id} className="space-y-2 rounded-2xl border bg-card p-4 shadow-soft">
          <div className="flex items-start justify-between gap-2">
            <div>
              <p className="flex items-center gap-1.5 font-semibold"><User className="h-4 w-4 text-gold" /> {order.customer_name || "Guest Customer"}</p>
              <p className="mt-1 flex items-center gap-1.5 text-sm text-muted-foreground">
                <Phone className="h-4 w-4 text-gold" />
                <a href={`tel:${order.customer_phone}`} className="underline">{order.customer_phone || "No phone provided"}</a>
              </p>
            </div>
            <span className={`shrink-0 rounded-full px-2.5 py-1 text-xs font-medium capitalize ${statusStyle(order.status ?? "pending")}`}>{order.status ?? "pending"}</span>
          </div>
          {order.customer_address && (
            <p className="flex items-center gap-1.5 text-sm text-muted-foreground"><MapPin className="h-4 w-4 text-accent" /> {order.customer_address}</p>
          )}
          <ul className="space-y-1 border-t pt-2 text-sm">
            {(order.items ?? []).map((l, i) => <li key={i} className="flex justify-between"><span>{l.qty} × {l.name} <span className="text-muted-foreground">({l.size})</span></span><span>{inr(l.price * l.qty)}</span></li>)}
          </ul>
          <div className="flex items-center justify-between border-t pt-2 text-sm font-semibold">
            <span>Total Amount:</span><span>{inr(order.total)}</span>
          </div>
          <div className="flex flex-wrap gap-2 pt-1">
            {ORDER_STATUSES.filter((s) => s !== order.status).map((s) => (
              <button key={s} onClick={() => setStatus(order.id, s)}
                className="rounded-full border px-3 py-1 text-xs capitalize hover:border-gold">{s}</button>
            ))}
          </div>
        </div>
      ))}
    </div>
  );
}

function ApplicationsPanel() {
  const [apps, setApps] = useState<Application[]>([]);
  const load = () => supabase.from("staff_applications").select("*").order("applied_at", { ascending: false })
    .then(({ data }) => setApps((data ?? []) as Application[]));
  useEffect(() => { load(); }, []);
  if (apps.length === 0) return <p className="mb-8 text-sm text-muted-foreground">No staff applications yet.</p>;
  const setStatus = async (id: number, status: string) => {
    const { error } = await supabase.from("staff_applications").update({ status }).eq("id", id).select("id").single();
    if (error) { toast.error("Unable to update application: " + error.message); return; }
    toast.success("Application " + status); load();
  };
  return (
    <div className="mb-8 rounded-3xl border bg-card p-6 shadow-soft">
      <h3 className="text-xl font-bold">Staff Applications</h3>
      <ul className="mt-4 space-y-3">
        {apps.map((a) => (
          <li key={a.id} className="rounded-xl border bg-background p-4 text-sm">
            <div className="flex items-center justify-between">
              <p className="font-medium">{a.full_name}</p>
              <span className="rounded-full bg-accent px-2.5 py-0.5 text-[11px] font-medium">{a.status}</span>
            </div>
            <p className="mt-1 text-xs text-muted-foreground">{a.phone}{a.experience ? ` · ${a.experience}` : ""}</p>
            {a.available_shifts && <p className="mt-1 text-xs text-muted-foreground">Shifts: {a.available_shifts}</p>}
            {a.why_join && <p className="mt-1 text-xs text-muted-foreground">Why join: {a.why_join}</p>}
            {a.prior_experience && <p className="mt-1 text-xs text-muted-foreground">Prior experience: {a.prior_experience}</p>}
            {a.status === "pending" && (
              <div className="mt-3 flex gap-2">
                <button onClick={() => setStatus(a.id, "accepted")} className="flex-1 rounded-lg bg-primary px-3 py-1.5 text-xs text-primary-foreground">Accept</button>
                <button onClick={() => setStatus(a.id, "rejected")} className="flex-1 rounded-lg border border-destructive/40 px-3 py-1.5 text-xs text-destructive">Reject</button>
              </div>
            )}
          </li>
        ))}
      </ul>
    </div>
  );
}
