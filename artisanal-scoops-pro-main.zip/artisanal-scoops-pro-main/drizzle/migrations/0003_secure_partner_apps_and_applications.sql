ALTER TABLE public.website_settings ADD COLUMN IF NOT EXISTS apps jsonb NOT NULL DEFAULT '[]'::jsonb;
UPDATE public.website_settings SET apps = COALESCE(allowed_apps, '[]'::jsonb);
COMMENT ON COLUMN public.website_settings.allowed_apps IS 'DEPRECATED: replaced by apps';
GRANT SELECT ON public.flavours, public.website_settings TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.flavours, public.website_settings, public.user_roles TO authenticated;
GRANT SELECT, INSERT, UPDATE ON public.staff_applications TO authenticated;
GRANT ALL ON public.flavours, public.website_settings, public.user_roles, public.staff_applications TO service_role;
GRANT USAGE, SELECT ON SEQUENCE public.staff_applications_id_seq TO authenticated, service_role;
ALTER TABLE public.flavours ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.staff_applications ENABLE ROW LEVEL SECURITY;
ALTER POLICY "Customers submit own application" ON public.staff_applications WITH CHECK (auth.uid() = customer_id AND NOT (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'staff')));
CREATE OR REPLACE FUNCTION public.validate_meltora_application() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
 IF TG_OP = 'INSERT' AND NEW.status <> 'pending' THEN RAISE EXCEPTION 'New applications must be pending'; END IF;
 IF TG_OP = 'INSERT' AND (length(trim(coalesce(NEW.full_name,''))) = 0 OR length(trim(coalesce(NEW.phone,''))) = 0 OR length(trim(coalesce(NEW.experience,''))) = 0 OR length(trim(coalesce(NEW.why_join,''))) = 0 OR length(trim(coalesce(NEW.available_shifts,''))) = 0 OR length(trim(coalesce(NEW.prior_experience,''))) = 0) THEN RAISE EXCEPTION 'All application fields are required'; END IF;
 IF NEW.status NOT IN ('pending','accepted','approved','rejected') THEN RAISE EXCEPTION 'Invalid application status'; END IF;
 IF TG_OP = 'UPDATE' AND NEW.customer_id IS DISTINCT FROM OLD.customer_id THEN RAISE EXCEPTION 'Application ownership cannot change'; END IF;
 RETURN NEW;
END; $$;
CREATE TRIGGER validate_meltora_application BEFORE INSERT OR UPDATE ON public.staff_applications FOR EACH ROW EXECUTE FUNCTION public.validate_meltora_application();
CREATE OR REPLACE FUNCTION public.validate_meltora_apps() RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
DECLARE app jsonb;
BEGIN
 IF jsonb_typeof(NEW.apps) <> 'array' THEN RAISE EXCEPTION 'Apps must be an array'; END IF;
 FOR app IN SELECT value FROM jsonb_array_elements(NEW.apps) LOOP
 IF jsonb_typeof(app) <> 'object' OR length(trim(coalesce(app->>'name',''))) = 0 OR coalesce(app->>'url','') !~ '^https?://[^[:space:]]+$' THEN RAISE EXCEPTION 'Each app needs a name and a valid HTTP or HTTPS URL'; END IF;
 END LOOP;
 RETURN NEW;
END; $$;
CREATE TRIGGER validate_meltora_apps BEFORE INSERT OR UPDATE ON public.website_settings FOR EACH ROW EXECUTE FUNCTION public.validate_meltora_apps();