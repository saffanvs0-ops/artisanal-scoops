CREATE TABLE public.flavours (
    id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT,
    category TEXT DEFAULT 'Scoops',
    badges TEXT[] DEFAULT '{}',
    image_url TEXT,
    stock_count INT DEFAULT 50,
    price_single NUMERIC NOT NULL DEFAULT 149,
    price_double NUMERIC NOT NULL DEFAULT 249,
    price_tub NUMERIC NOT NULL DEFAULT 499,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

GRANT SELECT ON public.flavours TO anon;
GRANT SELECT, INSERT, UPDATE, DELETE ON public.flavours TO authenticated;
GRANT ALL ON public.flavours TO service_role;

ALTER TABLE public.flavours ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Allow public read access"
ON public.flavours FOR SELECT
USING (true);

CREATE POLICY "Allow full access to admin"
ON public.flavours FOR ALL
TO authenticated
USING (auth.role() = 'authenticated')
WITH CHECK (auth.role() = 'authenticated');