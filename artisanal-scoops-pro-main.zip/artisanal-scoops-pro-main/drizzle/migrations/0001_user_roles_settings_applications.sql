CREATE TYPE public.app_role AS ENUM ('owner', 'manager', 'staff', 'customer');

CREATE TABLE public.user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
    role public.app_role NOT NULL,
    UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role public.app_role)
RETURNS BOOLEAN LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

CREATE POLICY "Users can read own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "Owners can manage roles" ON public.user_roles FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'owner'));

CREATE TABLE public.website_settings (
    id INT PRIMARY KEY DEFAULT 1,
    phone_number VARCHAR(20),
    instagram_id VARCHAR(50),
    allowed_apps JSONB,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT single_row CHECK (id = 1)
);
GRANT SELECT ON public.website_settings TO anon, authenticated;
GRANT ALL ON public.website_settings TO service_role;
ALTER TABLE public.website_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Public can read settings" ON public.website_settings FOR SELECT USING (true);
CREATE POLICY "Owner can manage settings" ON public.website_settings FOR ALL TO authenticated USING (public.has_role(auth.uid(), 'owner'));

CREATE TABLE public.staff_applications (
    id SERIAL PRIMARY KEY,
    customer_id UUID NOT NULL,
    full_name VARCHAR(100) NOT NULL,
    phone VARCHAR(20) NOT NULL,
    experience TEXT,
    status VARCHAR(20) DEFAULT 'pending',
    applied_at TIMESTAMPTZ DEFAULT CURRENT_TIMESTAMP
);
GRANT SELECT, INSERT, UPDATE ON public.staff_applications TO authenticated;
GRANT ALL ON public.staff_applications TO service_role;
ALTER TABLE public.staff_applications ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Customers submit own application" ON public.staff_applications FOR INSERT TO authenticated WITH CHECK (auth.uid() = customer_id);
CREATE POLICY "Applicants read own application" ON public.staff_applications FOR SELECT TO authenticated USING (auth.uid() = customer_id);
CREATE POLICY "Owner and manager review applications" ON public.staff_applications FOR SELECT TO authenticated USING (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'manager'));
CREATE POLICY "Owner and manager update applications" ON public.staff_applications FOR UPDATE TO authenticated USING (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'manager'));

DROP POLICY "Allow full access to admin" ON public.flavours;
CREATE POLICY "Staff roles manage flavours" ON public.flavours FOR ALL TO authenticated
USING (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'staff'))
WITH CHECK (public.has_role(auth.uid(), 'owner') OR public.has_role(auth.uid(), 'manager') OR public.has_role(auth.uid(), 'staff'));