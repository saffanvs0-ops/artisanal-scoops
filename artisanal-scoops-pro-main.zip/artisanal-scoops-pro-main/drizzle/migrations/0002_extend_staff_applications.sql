ALTER TABLE public.staff_applications ADD COLUMN why_join TEXT;
ALTER TABLE public.staff_applications ADD COLUMN available_shifts VARCHAR(100);
ALTER TABLE public.staff_applications ADD COLUMN prior_experience TEXT;